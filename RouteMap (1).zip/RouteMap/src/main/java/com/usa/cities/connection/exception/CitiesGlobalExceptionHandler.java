package com.usa.cities.connection.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@EnableWebMvc
@ControllerAdvice
public class CitiesGlobalExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(CitiesException.class)
	public final ResponseEntity<ErrorDetails> handleProcessingException(CitiesException ex, WebRequest request) {
		ErrorDetails errorDetails = new ErrorDetails(ex.getErrorMessage(), ex.getCode());
		return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
	}
}
