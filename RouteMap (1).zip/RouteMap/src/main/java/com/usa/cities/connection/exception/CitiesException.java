package com.usa.cities.connection.exception;

import lombok.Getter;

@Getter
public class CitiesException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5016228917947959051L;
	
	private final String errorMessage;
	private final int code;

	public CitiesException(int code, String errorMessage) {
		this.code = code;
		this.errorMessage = errorMessage;
	}

}
