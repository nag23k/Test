package com.usa.cities.connection.exception;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ErrorDetails {
	
	private Integer statusCode;
	private String message;
	
	public ErrorDetails(String message,Integer statusCode) {
		this.message = message;
		this.statusCode = statusCode;
	}


}
