package com.usa.cities.connection.config;

import java.io.File;
import java.nio.file.Files;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.ResourceUtils;

import com.usa.cities.connection.exception.CitiesException;
import com.usa.cities.connection.model.CitiesRepository;

@Configuration
public class CityConfig {

	@Bean
	public CitiesRepository getCitiesMapping() {
		CitiesRepository citiesModel = new CitiesRepository();
		try {
			File file = ResourceUtils.getFile("classpath:city.txt");
			List<String> allLines = Files.readAllLines(file.toPath());
			Map<String, String> cityData = allLines.stream().map(s -> s.trim().split(","))
	                .collect(Collectors.toMap(s -> s[0],
	                		s -> s[1], (first, second) -> first.trim()));
			citiesModel.setCities(cityData);
		} catch (Exception e) {
			throw new CitiesException(400, "Unable to load cities file");
		}
		return citiesModel;
	}
	
}
