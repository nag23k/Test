package com.usa.cities.connection.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.usa.cities.connection.exception.CitiesException;
import com.usa.cities.connection.service.CityService;

@RestController
@RequestMapping("/")
public class CitiesConnectionController {
	
	@Autowired
	private CityService cityService;
	
	
	@GetMapping("connected")
	public String getRoadMap(@RequestParam("origin") String origin, @RequestParam("destination") String destination) {
		if(!StringUtils.hasText(origin) || !StringUtils.hasText(destination)) {
			throw new CitiesException(400, "Invalid Parameters (Origin/Destination)");
		}
		boolean route = cityService.isRouteExisted(origin, destination);
		if(route) {
			return "Yes";
		}
		return "No";
	}

}
