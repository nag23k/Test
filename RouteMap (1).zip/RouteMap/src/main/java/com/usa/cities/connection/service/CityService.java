package com.usa.cities.connection.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usa.cities.connection.model.CitiesRepository;

@Service
public class CityService {
	
	@Autowired
	private CitiesRepository citiesRepository;
	
	public boolean isRouteExisted(String origin, String destination) {
		String dest = citiesRepository.getCities().getOrDefault(origin,"");
		if(destination.trim().equalsIgnoreCase(dest.trim())) {
			return true;
		}else {
			return false;
		}
	}

}
