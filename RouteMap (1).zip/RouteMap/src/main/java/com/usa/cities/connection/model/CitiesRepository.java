package com.usa.cities.connection.model;

import java.util.Map;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CitiesRepository {
	
	private Map<String,String> cities;

}
