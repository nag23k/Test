package com.usa.cities.connection.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.usa.cities.connection.model.CitiesRepository;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CityServiceTest {
	
	
	@InjectMocks
	private CityService cityService; 
	
	@Mock
	CitiesRepository citiesRepository;
	
	@Test
	public void isRouteExistedTest()
	{
	String origin="organ";
	String destination="dest";
	boolean b2=false;
	Map<String,String> getCities=new HashMap<String, String>();
	getCities.put("test", "test");
	citiesRepository.setCities(getCities);
	when(citiesRepository.getCities()).thenReturn(getCities);
	boolean b1=cityService.isRouteExisted(origin, destination);
	assertEquals(b2, b1);
	}

	
	@Test
	public void isRouteExistedTrueTest()
	{
	String origin="organ";
	String destination=" ";
	boolean b2=true;
	Map<String,String> getCities=new HashMap<String, String>();
	getCities.put("dest", "dest");
	citiesRepository.setCities(getCities);
	when(citiesRepository.getCities()).thenReturn(getCities);
	boolean b1=cityService.isRouteExisted(origin, destination);
	assertEquals(b2, b1);
	}
}
