package com.usa.cities.connection.controller;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.StringUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import com.usa.cities.connection.exception.CitiesException;
import com.usa.cities.connection.service.CityService;

@RunWith(MockitoJUnitRunner.Silent.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class CitiesConnectionControllerTest {
	
	@InjectMocks
	CitiesConnectionController citiesConnectionController;
	
	@Mock
	CityService cityService;
	
	@Mock
	StringUtils stringUtil;
	
	@Rule
	public ExpectedException thrown = ExpectedException.none();
	
	@Test
	public void getRoadMaptrueTest() {
		String origin="origin";
		String destination="destination";
		String truevalue="Yes";
		when(cityService.isRouteExisted(origin, destination)).thenReturn(Boolean.TRUE);
		String value=citiesConnectionController.getRoadMap(origin, destination);
		assertEquals(value, truevalue);
	}
	
	@Test
	public void getRoadMapfalseTest() {
		String origin="origin";
		String destination="destination";
		String truevalue="No";
		when(cityService.isRouteExisted(origin, destination)).thenReturn(Boolean.FALSE);
		String value=citiesConnectionController.getRoadMap(origin, destination);
		assertEquals(value, truevalue);
	}

	@Test
	public void getRoadMapfalseexceptionoriginTest()
	{
		String origin=" ";
		String destination="destination";
		thrown.expect(CitiesException.class);
		String value=citiesConnectionController.getRoadMap(origin, destination);
	}
	
	
	@Test
	public void getRoadMapfalseexceptiondestinationTest()
	{
		String origin="origin";
		String destination="";
		thrown.expect(CitiesException.class);
		String value=citiesConnectionController.getRoadMap(origin, destination);
	}
	
}
